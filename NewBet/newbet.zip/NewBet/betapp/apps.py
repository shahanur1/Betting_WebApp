from django.apps import AppConfig


class BetappConfig(AppConfig):
    name = 'betapp'
